export class Details {

    days : any [] = [ "monday", "tuesday", "wednesday", "thursday  ",  "friday",];

    persons : any [] = [

       {
            "users" : [

                {
                    "usersID" : "2592277",
                    "Name" : "Karabo Makhowane",
                    "bio" : "Web developer"
                },
        
                {
                    "usersID" : "7722952",
                    "Name" : "Antonia",
                    "bio" : "Software enginner"
                },
        
                {
                    "usersID" : "95253377",
                    "Name" : "Wilson",
                    "bio" : "App developer"
                },

                {
                    "usersID" : "88553315",
                    "Name" : "Tania",
                    "bio" : "Graphic designer"
                
                },

                
               ],
            
            
            }
        ]

}


  