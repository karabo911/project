import { Injectable } from '@angular/core';
import { Details } from './details';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(public data : Details){}

  getDays(){

    return this.data.days;
  }

}