import { element } from 'protractor';
import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';
import { profile } from 'console';
import {MatCardModule} from '@angular/material/card';


@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {

  //variable declaration 

  Days : any;
  
  
  

  constructor(public weekday : ApiService) { }

  ngOnInit() {

    this.Days = this.weekday.getDays();
   
      
    
  }

}
